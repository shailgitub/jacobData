package usbdssaccount.midsetup;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MidSetupApplicationTests {

	@Test
	void contextLoads() {
	}

}
