package usbdssaccount.midsetup;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
//@ComponentScan(basePackages="usbdssaccount.midsetup.controller")
@ComponentScan({"usbdssaccount.midsetup.controller"})
public class MidSetupApplication {

	public static void main(String[] args) {
		SpringApplication.run(MidSetupApplication.class, args);
	}

}
