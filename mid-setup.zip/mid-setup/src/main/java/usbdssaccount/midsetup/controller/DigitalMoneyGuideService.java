package usbdssaccount.midsetup.controller;

import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import usbdssaccount.midsetup.model.CustomerKey;
import usbdssaccount.midsetup.model.MoneyGuide;
import usbdssaccount.midsetup.model.MoneyGuideBliss;
import usbdssaccount.midsetup.model.MoneyGuideBlock;
import usbdssaccount.midsetup.model.MoneyGuideLab;
import usbdssaccount.midsetup.model.MoneyGuidePro;

@Service
public class DigitalMoneyGuideService {

	private static final String MONEY_GUIDE_PRO_ENDPOINT_URL = "https://plexit.us.bank-dns.com:19443/hogan/digital-ids/v1/money-guide-pro-ids";

	public MoneyGuide createMoneyGuideProResource(MoneyGuide moneyguide) {

		RestTemplate restTemplate = new RestTemplate();
		 MoneyGuide result = restTemplate.postForObject(MONEY_GUIDE_PRO_ENDPOINT_URL, moneyguide, MoneyGuide.class);
		// System.out.println(result);
		 return result;
		
	}

	public MoneyGuide createMoneyGuideProResourceV1() {

		CustomerKey customerKey = new CustomerKey(0, "testKey", 0, 0);
		MoneyGuideBliss moneyGuideBliss = new MoneyGuideBliss("testBliss", "12-10-2011", "12:35");
		MoneyGuideBlock moneyGuideBlock = new MoneyGuideBlock("testBlock", "12-10-2011", "12:35");
		MoneyGuideLab moneyGuideLab = new MoneyGuideLab("testLab", "12-10-2011", "12:35");
		MoneyGuidePro MoneyGuidePro = new MoneyGuidePro("testGP", "12-10-2011", "12:35");
		return new MoneyGuide("BJKP5468", customerKey, "Active", moneyGuideBliss, moneyGuideBlock, moneyGuideLab,
				MoneyGuidePro);

		// RestTemplate restTemplate = new RestTemplate();
		// Moneyguide result =
		// restTemplate.postForObject(MONEY_GUIDE_PRO_ENDPOINT_URL,
		// moneyguideDTO, Moneyguide.class);
		// System.out.println(result);

	}

	public MoneyGuide createMoneyGuideProResourceV2() {

		MoneyGuide moneyguideDTO;
		CustomerKey customerKey = new CustomerKey(0, "testKey", 0, 0);
		MoneyGuideBliss moneyGuideBliss = new MoneyGuideBliss("testBliss", "12-10-2011", "12:35");
		MoneyGuideBlock moneyGuideBlock = new MoneyGuideBlock("testBlock", "12-10-2011", "12:35");
		MoneyGuideLab moneyGuideLab = new MoneyGuideLab("testLab", "12-10-2011", "12:35");
		MoneyGuidePro MoneyGuidePro = new MoneyGuidePro("testGP", "12-10-2011", "12:35");
		moneyguideDTO= new MoneyGuide("BJKP5468", customerKey, "Active", moneyGuideBliss, moneyGuideBlock, moneyGuideLab,
				MoneyGuidePro);

		 RestTemplate restTemplate = new RestTemplate();
		 MoneyGuide result = restTemplate.postForObject(MONEY_GUIDE_PRO_ENDPOINT_URL, moneyguideDTO, MoneyGuide.class);
		// System.out.println(result);
		 return result;

	}
}
