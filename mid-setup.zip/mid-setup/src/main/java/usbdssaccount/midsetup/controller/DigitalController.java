package usbdssaccount.midsetup.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import usbdssaccount.midsetup.model.MoneyGuide;

@RestController
@RequestMapping("/digital-ids")
public class DigitalController {

	@Autowired
	public DigitalMoneyGuideService digitalMoneyGuideService;

	@GetMapping("/v1/money-guide-pro-ids")
	private MoneyGuide createMoneyGuidePro() {
		return digitalMoneyGuideService.createMoneyGuideProResourceV1();
		
	}

	@PostMapping("/v1/post-money-guide-pro")
	public MoneyGuide createMoneyGuideProV2(@RequestBody MoneyGuide moneyguide) {
		// return new Moneyguide("BJPP43535", "Active");
		//return digitalMoneyGuideService.createMoneyGuideProResource(moneyguide);
		return digitalMoneyGuideService.createMoneyGuideProResource(moneyguide);
		
	}

	// @PostMapping("/employees")
	// public Employee createEmployee(@Valid @RequestBody Employee employee) {
	// return employeeRepository.save(employee);
	// }

}
