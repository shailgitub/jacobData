package usbdssaccount.midsetup.model;

import java.io.Serializable;

public class CustomerKey implements Serializable{
	private static final long serialVersionUID = 1L;
	private int companyID;
    private String name;
    private int tiebreaker;
    private int legalParticipantID;
    
    
	public CustomerKey() {
		super();
		// TODO Auto-generated constructor stub
	}
	public CustomerKey(int companyID, String name, int tiebreaker, int legalParticipantID) {
		super();
		this.companyID = companyID;
		this.name = name;
		this.tiebreaker = tiebreaker;
		this.legalParticipantID = legalParticipantID;
	}
	public int getCompanyID() {
		return companyID;
	}
	public void setCompanyID(int companyID) {
		this.companyID = companyID;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getTiebreaker() {
		return tiebreaker;
	}
	public void setTiebreaker(int tiebreaker) {
		this.tiebreaker = tiebreaker;
	}
	public int getLegalParticipantID() {
		return legalParticipantID;
	}
	public void setLegalParticipantID(int legalParticipantID) {
		this.legalParticipantID = legalParticipantID;
	}

	
    
	
}
