package usbdssaccount.midsetup.model;

import java.io.Serializable;

public class MoneyGuidePro implements Serializable{
	private static final long serialVersionUID = 1L;
	private String accessFlag;
	private String accessDate;
	private String accessTime;

	public MoneyGuidePro() {
		super();
		// TODO Auto-generated constructor stub
	}

	public MoneyGuidePro(String accessFlag, String accessDate, String accessTime) {
		super();
		this.accessFlag = accessFlag;
		this.accessDate = accessDate;
		this.accessTime = accessTime;
	}

	public String getAccessFlag() {
		return accessFlag;
	}

	public void setAccessFlag(String accessFlag) {
		this.accessFlag = accessFlag;
	}

	public String getAccessDate() {
		return accessDate;
	}

	public void setAccessDate(String accessDate) {
		this.accessDate = accessDate;
	}

	public String getAccessTime() {
		return accessTime;
	}

	public void setAccessTime(String accessTime) {
		this.accessTime = accessTime;
	}
}
