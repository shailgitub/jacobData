package usbdssaccount.midsetup.model;

import java.io.Serializable;

public class MoneyGuide implements Serializable{
	private static final long serialVersionUID = 1L;
	private String bankerPreferredID;
	private CustomerKey customerKey;
	private String accountStatus;
	private MoneyGuideBliss moneyGuideBliss;
	private MoneyGuideBlock moneyGuideBlock;
	private MoneyGuideLab moneyGuideLab;
	private MoneyGuidePro moneyGuidePro;
	
	
	public MoneyGuide() {
		super();
		// TODO Auto-generated constructor stub
	}

	public MoneyGuide(String bankerPreferredID, CustomerKey customerKey, String accountStatus,
			MoneyGuideBliss moneyGuideBliss, MoneyGuideBlock moneyGuideBlock, MoneyGuideLab moneyGuideLab,
			MoneyGuidePro moneyGuidePro) {
		super();
		this.bankerPreferredID = bankerPreferredID;
		this.customerKey = customerKey;
		this.accountStatus = accountStatus;
		this.moneyGuideBliss = moneyGuideBliss;
		this.moneyGuideBlock = moneyGuideBlock;
		this.moneyGuideLab = moneyGuideLab;
		this.moneyGuidePro = moneyGuidePro;
	}

	public String getBankerPreferredID() {
		return bankerPreferredID;
	}

	public void setBankerPreferredID(String bankerPreferredID) {
		this.bankerPreferredID = bankerPreferredID;
	}

	public CustomerKey getCustomerKey() {
		return customerKey;
	}

	public void setCustomerKey(CustomerKey customerKey) {
		this.customerKey = customerKey;
	}

	public String getAccountStatus() {
		return accountStatus;
	}

	public void setAccountStatus(String accountStatus) {
		this.accountStatus = accountStatus;
	}

	public MoneyGuideBliss getMoneyGuideBliss() {
		return moneyGuideBliss;
	}

	public void setMoneyGuideBliss(MoneyGuideBliss moneyGuideBliss) {
		this.moneyGuideBliss = moneyGuideBliss;
	}

	public MoneyGuideBlock getMoneyGuideBlock() {
		return moneyGuideBlock;
	}

	public void setMoneyGuideBlock(MoneyGuideBlock moneyGuideBlock) {
		this.moneyGuideBlock = moneyGuideBlock;
	}

	public MoneyGuideLab getMoneyGuideLab() {
		return moneyGuideLab;
	}

	public void setMoneyGuideLab(MoneyGuideLab moneyGuideLab) {
		this.moneyGuideLab = moneyGuideLab;
	}

	public MoneyGuidePro getMoneyGuidePro() {
		return moneyGuidePro;
	}

	public void setMoneyGuidePro(MoneyGuidePro moneyGuidePro) {
		this.moneyGuidePro = moneyGuidePro;
	}
	
	
	
	
}
